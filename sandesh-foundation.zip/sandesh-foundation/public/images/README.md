# Images

Copy these 8 files from the saved-page folder
`Sandesh Foundation — सेवा ही संदेश_files/` (next to the HTML you saved) into this
directory, keeping the exact names:

- logo.jpg
- founder.jpg
- education.jpg
- healthcare.jpg
- environment.jpg
- about.jpg
- main2.jpg
- foundation-day.jpg

The 7 stock photos (hero, women, cloth donation, school, doctor, saplings, joy) are
loaded from Unsplash by default — see `src/lib/images.ts`.
