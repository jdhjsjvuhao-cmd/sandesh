/** Theme values were read from the compiled CSS of the reference site. */
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        clay: "#FDFBF7",
        ink: "#1F1210",
        maroon: { DEFAULT: "#58181D", deep: "#421014" },
        saffron: { DEFAULT: "#D97706", bright: "#F59E0B" },
        sand: "#F5EFE6",
        terracotta: "#9A3412",
      },
      fontFamily: {
        sans: ['"DM Sans"', "ui-sans-serif", "system-ui", "sans-serif"],
        serif: ['"Fraunces"', "Georgia", "serif"],
      },
    },
  },
  plugins: [],
};
