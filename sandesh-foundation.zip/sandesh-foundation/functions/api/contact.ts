import { clip, json, readBody, type Env } from "../_lib";

export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  const body = await readBody(request);
  if (!body) return json({ error: "Invalid request." }, 400);

  const name = clip(body.name, 120);
  const phone = clip(body.phone, 30);
  const subject = clip(body.subject, 200);
  const message = clip(body.message, 4000);

  if (!name || !message) return json({ error: "Name and message are required." }, 400);

  try {
    await env.DB.prepare(
      `INSERT INTO inquiries (name, phone, subject, message) VALUES (?1, ?2, ?3, ?4)`,
    )
      .bind(name, phone, subject, message)
      .run();
  } catch {
    return json({ error: "Could not send your message right now. Please call us." }, 500);
  }
  return json({ ok: true }, 201);
};
