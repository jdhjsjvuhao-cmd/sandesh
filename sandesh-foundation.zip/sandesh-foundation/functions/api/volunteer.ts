import { clip, json, readBody, type Env } from "../_lib";

const ALLOWED_AVAILABILITY = ["Weekends", "Weekdays", "Remote / online", "Anytime"];

export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  const body = await readBody(request);
  if (!body) return json({ error: "Invalid request." }, 400);

  const name = clip(body.name, 120);
  const phone = clip(body.phone, 30);
  const email = clip(body.email, 160);
  const city = clip(body.city, 120);
  const notes = clip(body.notes, 2000);
  const availability = ALLOWED_AVAILABILITY.includes(clip(body.availability, 40))
    ? clip(body.availability, 40)
    : "Weekends";
  const interests = Array.isArray(body.interests)
    ? body.interests.filter((i): i is string => typeof i === "string").map((i) => i.slice(0, 60)).slice(0, 10)
    : [];

  if (!name || !phone) return json({ error: "Name and phone are required." }, 400);
  if (!/^[0-9+()\-\s]{7,20}$/.test(phone)) return json({ error: "Please enter a valid phone number." }, 400);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Please enter a valid email." }, 400);

  try {
    await env.DB.prepare(
      `INSERT INTO volunteers (name, phone, email, city, interests, availability, notes)
       VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)`,
    )
      .bind(name, phone, email, city, interests.join(", "), availability, notes)
      .run();
  } catch {
    return json({ error: "Could not save your details right now. Please call us." }, 500);
  }
  return json({ ok: true }, 201);
};
