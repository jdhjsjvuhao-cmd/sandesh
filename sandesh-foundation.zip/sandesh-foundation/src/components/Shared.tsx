import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { IMG } from "../lib/images";
import { ORG } from "../lib/content";
import { scrollToTop } from "../lib/scroll";

/** Scroll-in wrapper used across sections. */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

interface SectionHeadingProps {
  hindi: string;
  english: string;
  title: string;
  description?: string;
  /** "dark" = used on maroon background */
  tone?: "light" | "dark";
}

export function SectionHeading({
  hindi,
  english,
  title,
  description,
  tone = "light",
}: SectionHeadingProps) {
  const dark = tone === "dark";
  return (
    <div className="max-w-3xl">
      <Reveal>
        <p
          className={`flex items-center gap-3 text-xs font-medium uppercase tracking-[0.25em] ${
            dark ? "text-saffron-bright" : "text-saffron"
          }`}
        >
          <span className="inline-block h-px w-8 bg-current"></span>
          {hindi} · {english}
        </p>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          className={`mt-5 font-serif text-3xl leading-[1.12] tracking-tight sm:text-4xl lg:text-5xl ${
            dark ? "text-clay" : "text-maroon"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {description && (
        <Reveal delay={0.16}>
          <p
            className={`mt-5 max-w-2xl text-base leading-relaxed sm:text-lg ${
              dark ? "text-stone-300" : "text-stone-600"
            }`}
          >
            {description}
          </p>
        </Reveal>
      )}
    </div>
  );
}

export function Logo({ tone }: { tone: "onLight" | "onDark" }) {
  const dark = tone === "onDark";
  return (
    <button
      data-testid="nav-logo-button"
      onClick={scrollToTop}
      className="flex items-center gap-3 text-left"
      aria-label="Sandesh Foundation — back to top"
    >
      <img
        src={IMG.logo}
        alt="Sandesh Foundation emblem"
        className="h-10 w-10 shrink-0 rounded-full bg-white object-cover shadow-sm ring-1 ring-maroon/20"
      />
      <span className="leading-tight">
        <span
          className={`block font-serif text-[17px] font-semibold tracking-tight ${
            dark ? "text-clay" : "text-maroon"
          }`}
        >
          {ORG.name}
        </span>
        <span
          className={`hindi block text-[11px] ${
            dark ? "text-saffron-bright" : "text-saffron"
          }`}
        >
          {ORG.tagline}
        </span>
      </span>
    </button>
  );
}

export function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M13.5 21v-7h2.4l.4-3h-2.8V9.1c0-.9.3-1.5 1.6-1.5h1.4V5.1C16.2 5.1 15.3 5 14.3 5c-2.2 0-3.8 1.4-3.8 3.9V11H8v3h2.5v7h3z" />
    </svg>
  );
}

export const inputClass =
  "w-full rounded-xl border border-maroon/15 bg-white px-4 py-3 text-sm text-ink placeholder-stone-400 outline-none transition-all focus:border-saffron focus:ring-2 focus:ring-saffron/30";
