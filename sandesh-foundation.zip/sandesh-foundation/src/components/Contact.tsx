import { useState, type FormEvent } from "react";
import { MapPin, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { ORG } from "../lib/content";
import { postJSON } from "../lib/api";
import { FacebookIcon, Reveal, SectionHeading, inputClass } from "./Shared";

export default function Contact() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) {
      toast.error("Please enter your name and a message.");
      return;
    }
    setSubmitting(true);
    const res = await postJSON("/api/contact", {
      name: name.trim(),
      phone: phone.trim(),
      subject: subject.trim(),
      message: message.trim(),
    });
    setSubmitting(false);
    if (!res.ok) {
      toast.error(res.message ?? "Could not send. Please try again or call us.");
      return;
    }
    toast.success("Message sent. Thank you — we will get back to you soon.");
    setName("");
    setPhone("");
    setSubject("");
    setMessage("");
  };

  const iconWrap =
    "flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-saffron/15 text-saffron";
  const phoneIconWrap =
    "flex h-12 w-12 items-center justify-center rounded-full bg-saffron/15 text-saffron";

  return (
    <section id="contact" data-testid="contact-section" className="bg-sand py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-16">
          <div>
            <SectionHeading
              hindi="संपर्क"
              english="Contact"
              title="Come, say namaste."
              description="Whether you want to volunteer, invite us to your village, or partner on a programme — we would love to hear from you."
            />
            <div className="mt-10 space-y-6">
              <Reveal>
                <a
                  href={ORG.phoneHref}
                  data-testid="contact-phone-link"
                  className="flex items-center gap-4 rounded-2xl border border-maroon/10 bg-white/70 p-6 transition-all hover:border-saffron"
                >
                  <span className={phoneIconWrap}>
                    <Phone className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span>
                    <span className="block text-xs uppercase tracking-[0.2em] text-stone-500">Call us</span>
                    <span className="block font-serif text-xl text-maroon">{ORG.phoneDisplay}</span>
                  </span>
                </a>
              </Reveal>
              <Reveal>
                <div
                  data-testid="contact-location-card"
                  className="flex items-center gap-4 rounded-2xl border border-maroon/10 bg-white/70 p-6"
                >
                  <span className={iconWrap}>
                    <MapPin className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span>
                    <span className="block text-xs uppercase tracking-[0.2em] text-stone-500">Visit us</span>
                    <span className="block text-sm font-medium text-maroon">{ORG.address}</span>
                  </span>
                </div>
              </Reveal>
              <Reveal>
                <a
                  href={ORG.facebookUrl}
                  target="_blank"
                  rel="noreferrer"
                  data-testid="contact-facebook-link"
                  className="flex items-center gap-4 rounded-2xl border border-maroon/10 bg-white/70 p-6 transition-all hover:border-saffron"
                >
                  <span className={iconWrap}>
                    <FacebookIcon className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-xs uppercase tracking-[0.2em] text-stone-500">
                      Follow our work
                    </span>
                    <span className="block font-serif text-xl text-maroon">
                      Facebook — {ORG.facebookHandle}
                    </span>
                  </span>
                </a>
              </Reveal>
            </div>
          </div>

          <Reveal>
            <form
              data-testid="contact-form"
              onSubmit={onSubmit}
              noValidate
              className="rounded-3xl border border-maroon/10 bg-white p-7 sm:p-9"
            >
              <p className="font-serif text-2xl text-maroon">Send a quick inquiry</p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <input
                  data-testid="contact-name-input"
                  className={inputClass}
                  placeholder="Your name *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
                <input
                  data-testid="contact-phone-input"
                  className={inputClass}
                  placeholder="Phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  autoComplete="tel"
                  inputMode="tel"
                />
              </div>
              <input
                data-testid="contact-subject-input"
                className={`${inputClass} mt-4`}
                placeholder="Subject (e.g. volunteering, donation, partnership)"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
              <textarea
                data-testid="contact-message-input"
                className={`${inputClass} mt-4 min-h-[120px] resize-y`}
                placeholder="Your message *"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              <button
                type="submit"
                disabled={submitting}
                data-testid="contact-submit-button"
                className="mt-6 inline-flex w-full items-center justify-center gap-3 rounded-full bg-maroon px-7 py-4 text-sm font-semibold text-clay transition-all hover:bg-maroon-deep disabled:opacity-60"
              >
                {submitting ? "Sending…" : "Send Message"}
                <Send className="h-4 w-4" aria-hidden="true" />
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
