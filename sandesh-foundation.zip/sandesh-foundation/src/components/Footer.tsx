import { ArrowUp } from "lucide-react";
import { FOOTER_LINKS, ORG } from "../lib/content";
import { scrollToSection, scrollToTop } from "../lib/scroll";
import { FacebookIcon, Logo } from "./Shared";

export default function Footer() {
  return (
    <footer data-testid="footer-section" className="bg-ink text-stone-400">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
        <h2 className="max-w-4xl font-serif text-4xl leading-[1.1] tracking-tight text-clay sm:text-6xl">
          <span className="hindi text-saffron-bright">हाथ मिलाइए,</span> संदेश पहुँचाइए.
        </h2>
        <p className="mt-5 max-w-xl text-base leading-relaxed">
          Lend a hand, deliver the message. Join as a volunteer or support a programme — a
          healthier, educated and self-reliant society starts with one person.
        </p>
        <div className="mt-8 flex flex-wrap gap-4">
          <button
            data-testid="footer-volunteer-cta"
            onClick={() => scrollToSection("volunteer")}
            className="rounded-full bg-saffron px-7 py-4 text-sm font-semibold text-ink transition-colors hover:bg-saffron-bright"
          >
            Become a Volunteer
          </button>
          <button
            data-testid="footer-donate-cta"
            onClick={() => scrollToSection("donate")}
            className="rounded-full border border-clay/30 px-7 py-4 text-sm font-semibold text-clay transition-colors hover:bg-clay/10"
          >
            Donate
          </button>
        </div>

        <div className="mt-16 grid gap-10 border-t border-clay/10 pt-12 md:grid-cols-3">
          <div>
            <Logo tone="onDark" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed">
              A non-religious, non-profit, public service organization carrying a message of
              health, education and environment.
            </p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-stone-500">Explore</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {FOOTER_LINKS.map((l) => (
                <button
                  key={l.id}
                  data-testid={`footer-link-${l.id}`}
                  onClick={() => scrollToSection(l.id)}
                  className="w-fit text-sm text-stone-400 transition-colors hover:text-saffron-bright"
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-stone-500">Reach us</p>
            <a
              href={ORG.phoneHref}
              data-testid="footer-phone-link"
              className="mt-4 block font-serif text-2xl text-clay transition-colors hover:text-saffron-bright"
            >
              {ORG.phoneDisplay}
            </a>
            <p className="mt-2 max-w-xs text-sm leading-relaxed">{ORG.address}</p>
            <a
              href={ORG.facebookUrl}
              target="_blank"
              rel="noreferrer"
              data-testid="footer-facebook-link"
              className="mt-5 inline-flex items-center gap-2 rounded-full border border-clay/20 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-clay transition-colors hover:bg-clay/10"
            >
              <FacebookIcon className="h-4 w-4" />
              Facebook
            </a>
          </div>
        </div>

        <div className="mt-14 flex flex-wrap items-center justify-between gap-4 border-t border-clay/10 pt-8 text-xs">
          <p data-testid="footer-copyright">
            © {new Date().getFullYear()} Sandesh Foundation · Non-profit · Non-religious · Public
            service organization
          </p>
          <button
            data-testid="back-to-top-button"
            onClick={scrollToTop}
            className="inline-flex items-center gap-2 rounded-full border border-clay/20 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-clay transition-colors hover:bg-clay/10"
          >
            Back to top <ArrowUp className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </footer>
  );
}
