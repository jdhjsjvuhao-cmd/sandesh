import { useState, type FormEvent } from "react";
import { HeartHandshake, Send } from "lucide-react";
import { toast } from "sonner";
import { AVAILABILITY, INTERESTS, VOLUNTEER_POINTS, slug } from "../lib/content";
import { postJSON } from "../lib/api";
import { Reveal, SectionHeading, inputClass } from "./Shared";

export default function Volunteer() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [availability, setAvailability] = useState("Weekends");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const toggleInterest = (i: string) =>
    setInterests((cur) => (cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i]));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("Please enter your name and phone number.");
      return;
    }
    setSubmitting(true);
    const res = await postJSON("/api/volunteer", {
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      city: city.trim(),
      interests,
      availability,
      notes: notes.trim(),
    });
    setSubmitting(false);

    if (!res.ok) {
      toast.error(res.message ?? "Could not send. Please try again or call us.");
      return;
    }
    toast.success("Thank you! Our team will reach out to you soon.");
    setName("");
    setPhone("");
    setEmail("");
    setCity("");
    setInterests([]);
    setAvailability("Weekends");
    setNotes("");
  };

  return (
    <section
      id="volunteer"
      data-testid="volunteer-form-container"
      className="relative overflow-hidden bg-maroon py-24 lg:py-32"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-saffron/10 blur-3xl"
      ></div>
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-16">
          <div>
            <SectionHeading
              tone="dark"
              hindi="स्वयंसेवा"
              english="Volunteer"
              title="Become a Sandesh change agent."
              description="We want everyone to take active involvement as a volunteer — because it is the main door to helping the needy person, to supporting those who live below the bottom line of life."
            />
            <div className="mt-10 space-y-5">
              {VOLUNTEER_POINTS.map((p, i) => (
                <Reveal key={p} delay={i * 0.08}>
                  <div className="flex items-start gap-4">
                    <HeartHandshake
                      className="mt-0.5 h-5 w-5 shrink-0 text-saffron-bright"
                      aria-hidden="true"
                    />
                    <p className="text-base leading-relaxed text-stone-300">{p}</p>
                  </div>
                </Reveal>
              ))}
            </div>
            <Reveal>
              <p className="mt-10 border-l-2 border-saffron-bright pl-5 font-serif text-xl italic text-clay sm:text-2xl">
                "We can't help everyone, but everyone can help someone."
              </p>
            </Reveal>
          </div>

          <Reveal>
            <form
              data-testid="volunteer-form"
              onSubmit={onSubmit}
              noValidate
              className="rounded-3xl bg-clay p-7 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.5)] sm:p-9"
            >
              <p className="font-serif text-2xl text-maroon">हाथ मिलाइए — join the family</p>

              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <input
                  data-testid="volunteer-name-input"
                  className={inputClass}
                  placeholder="Full name *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
                <input
                  data-testid="volunteer-phone-input"
                  className={inputClass}
                  placeholder="Phone (WhatsApp) *"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  autoComplete="tel"
                  inputMode="tel"
                />
                <input
                  data-testid="volunteer-email-input"
                  className={inputClass}
                  placeholder="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
                <input
                  data-testid="volunteer-city-input"
                  className={inputClass}
                  placeholder="City / locality"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>

              <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-stone-500">
                Where can you help?
              </p>
              <div className="mt-3 flex flex-wrap gap-2" data-testid="volunteer-interest-chips">
                {INTERESTS.map((i) => {
                  const on = interests.includes(i);
                  return (
                    <button
                      key={i}
                      type="button"
                      aria-pressed={on}
                      data-testid={`volunteer-interest-chip-${slug(i)}`}
                      onClick={() => toggleInterest(i)}
                      className={`rounded-full border px-4 py-2 text-xs font-medium transition-all ${
                        on
                          ? "border-saffron bg-saffron text-ink"
                          : "border-maroon/20 text-stone-600 hover:border-saffron hover:text-maroon"
                      }`}
                    >
                      {i}
                    </button>
                  );
                })}
              </div>

              <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-stone-500">
                Availability
              </p>
              <div
                className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4"
                data-testid="volunteer-availability-group"
              >
                {AVAILABILITY.map((a) => (
                  <button
                    key={a}
                    type="button"
                    aria-pressed={availability === a}
                    data-testid={`volunteer-availability-${slug(a)}`}
                    onClick={() => setAvailability(a)}
                    className={`rounded-xl border px-3 py-2.5 text-xs font-medium transition-all ${
                      availability === a
                        ? "border-maroon bg-maroon text-clay"
                        : "border-maroon/20 text-stone-600 hover:border-maroon/50"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>

              <textarea
                data-testid="volunteer-notes-input"
                className={`${inputClass} mt-5 min-h-[96px] resize-y`}
                placeholder="Anything you'd like to tell us (optional)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />

              <button
                type="submit"
                disabled={submitting}
                data-testid="volunteer-submit-button"
                className="mt-6 inline-flex w-full items-center justify-center gap-3 rounded-full bg-saffron px-7 py-4 text-sm font-semibold text-ink transition-all hover:bg-saffron-bright disabled:opacity-60"
              >
                {submitting ? "Sending…" : "Join as a Volunteer"}
                <Send className="h-4 w-4" aria-hidden="true" />
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
