import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  GALLERY,
  GALLERY_FILTERS,
  categoryHindi,
  type GalleryCategory,
} from "../lib/content";
import { Reveal, SectionHeading } from "./Shared";

export default function Gallery() {
  const [filter, setFilter] = useState<"all" | GalleryCategory>("all");
  const items = filter === "all" ? GALLERY : GALLERY.filter((g) => g.category === filter);

  return (
    <section id="gallery" data-testid="photo-gallery-section" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading hindi="गैलरी" english="From the field" title="Moments that carry the message." />

        <Reveal>
          <div className="mt-10 flex flex-wrap gap-2" data-testid="gallery-filter-group">
            {GALLERY_FILTERS.map((f) => (
              <button
                key={f.key}
                data-testid={`gallery-filter-${f.key}`}
                onClick={() => setFilter(f.key)}
                aria-pressed={filter === f.key}
                className={`rounded-full border px-5 py-2 text-sm font-medium transition-all ${
                  filter === f.key
                    ? "border-maroon bg-maroon text-clay"
                    : "border-maroon/20 text-stone-600 hover:border-maroon/50 hover:text-maroon"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-8 grid auto-rows-[190px] grid-cols-2 gap-3 sm:auto-rows-[230px] md:grid-cols-3 md:gap-4">
          <AnimatePresence mode="popLayout">
            {items.map((g) => (
              <motion.button
                key={g.src + g.caption}
                layout
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.4 }}
                data-testid="gallery-item"
                className={`group relative overflow-hidden rounded-2xl ${g.tall ? "row-span-2" : ""}`}
              >
                <img
                  src={g.src}
                  alt={g.caption}
                  loading="lazy"
                  className="h-full w-full object-cover sepia-[18%] transition-all duration-700 group-hover:scale-105 group-hover:sepia-0"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"></div>
                <p className="absolute bottom-0 left-0 right-0 translate-y-3 p-4 text-left font-serif text-sm text-clay opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  {g.caption}
                  <span className="hindi ml-2 text-saffron-bright">{categoryHindi(g.category)}</span>
                </p>
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
