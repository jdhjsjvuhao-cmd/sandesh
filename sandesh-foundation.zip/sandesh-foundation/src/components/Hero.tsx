import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { IMG } from "../lib/images";
import { scrollToSection } from "../lib/scroll";

const lineReveal = {
  hidden: { y: "105%" },
  show: (i: number) => ({
    y: "0%",
    transition: { duration: 0.9, delay: 0.15 + i * 0.12, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] as const },
});

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section
      id="top"
      ref={ref}
      data-testid="hero-section"
      className="relative flex min-h-[100svh] flex-col overflow-hidden bg-ink"
    >
      <motion.div className="absolute inset-0" style={{ y: bgY }}>
        <motion.div
          className="h-full w-full"
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <img
            src={IMG.hero}
            alt="Children learning together at a Sandesh Foundation learning centre"
            className="h-full w-full object-cover"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-r from-ink/95 via-ink/70 to-ink/30"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/40"></div>
      </motion.div>

      <motion.div
        className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-end px-5 pb-16 pt-32 sm:px-8 md:pb-20"
        style={{ opacity: contentOpacity }}
      >
        <motion.p
          {...fadeUp(0.05)}
          className="mb-6 flex items-center gap-3 text-xs font-medium uppercase tracking-[0.3em] text-saffron-bright"
        >
          <span className="inline-block h-px w-10 bg-saffron-bright"></span>
          सेवा ही संदेश · Serving humanity since 2017
        </motion.p>

        <h1 className="font-serif text-[13vw] leading-[1.02] tracking-tight text-clay sm:text-7xl lg:text-8xl">
          <span className="block overflow-hidden pb-2 -mb-2">
            <motion.span className="block" variants={lineReveal} initial="hidden" animate="show" custom={0}>
              A message of
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-2 -mb-2">
            <motion.span className="block" variants={lineReveal} initial="hidden" animate="show" custom={1}>
              <em className="font-light italic text-saffron-bright">health,</em> education
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-2 -mb-2">
            <motion.span className="block" variants={lineReveal} initial="hidden" animate="show" custom={2}>
              &amp; environment.
            </motion.span>
          </span>
        </h1>

        <motion.p
          {...fadeUp(0.7)}
          className="mt-7 max-w-xl text-base leading-relaxed text-stone-300 sm:text-lg"
        >
          Sandesh Foundation is a non-religious, non-profit public service organization —
          founded by Indian Navy veteran Sandeep Pandey — working so that every citizen is
          healthy, educated and self-reliant.
        </motion.p>

        <motion.div {...fadeUp(0.85)} className="mt-9 flex flex-wrap items-center gap-4">
          <button
            data-testid="hero-volunteer-cta"
            onClick={() => scrollToSection("volunteer")}
            className="group inline-flex items-center gap-3 rounded-full bg-saffron px-7 py-4 text-sm font-semibold text-ink transition-all duration-300 hover:bg-saffron-bright hover:shadow-[0_12px_40px_-10px_rgba(245,158,11,0.6)]"
          >
            Become a Volunteer
            <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
          </button>
          <button
            data-testid="hero-donate-cta"
            onClick={() => scrollToSection("donate")}
            className="inline-flex items-center gap-3 rounded-full border border-clay/40 px-7 py-4 text-sm font-semibold text-clay transition-all duration-300 hover:border-clay hover:bg-clay/10"
          >
            Donate Now
          </button>
        </motion.div>
      </motion.div>

      <div className="relative z-10 border-t border-clay/15">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-5 text-xs tracking-wide text-stone-400 sm:px-8">
          <span data-testid="hero-trust-nonprofit" className="uppercase">Non-profit · Non-religious</span>
          <span data-testid="hero-trust-founder" className="uppercase">Founded by a Navy veteran</span>
          <span data-testid="hero-trust-location" className="uppercase">Unnao · Uttar Pradesh · India</span>
          <span className="hidden items-center gap-2 text-saffron-bright md:inline-flex">
            Scroll <ArrowDown className="h-4 w-4 animate-bounce" aria-hidden="true" />
          </span>
        </div>
      </div>
    </section>
  );
}
