import { ArrowUpRight } from "lucide-react";
import { PROGRAMS } from "../lib/content";
import { scrollToSection } from "../lib/scroll";
import { Reveal, SectionHeading } from "./Shared";

export default function Programs() {
  return (
    <section id="programs" data-testid="programs-bento-grid" className="bg-sand py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            hindi="कार्य क्षेत्र"
            english="Our Work"
            title="Six ways we carry the message to the ground."
          />
          <Reveal>
            <button
              data-testid="programs-volunteer-cta"
              onClick={() => scrollToSection("volunteer")}
              className="group inline-flex items-center gap-2 rounded-full border border-maroon/25 px-6 py-3 text-sm font-semibold text-maroon transition-all hover:bg-maroon hover:text-clay"
            >
              Lend a hand
              <ArrowUpRight
                className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                aria-hidden="true"
              />
            </button>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 lg:grid-cols-12">
          {PROGRAMS.map((p) => (
            <article
              key={p.n}
              data-testid={`program-card-${p.n}`}
              className={`group relative h-full overflow-hidden rounded-3xl bg-ink ${p.span}`}
            >
              <img
                src={p.image}
                alt={p.alt}
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover opacity-80 transition-all duration-700 group-hover:scale-105 group-hover:opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent"></div>
              <div className="relative flex h-full min-h-[320px] flex-col justify-end p-7 sm:p-9">
                <span className="font-serif text-sm text-saffron-bright">
                  {p.n} · <span className="hindi">{p.hindi}</span>
                </span>
                <h3 className="mt-2 font-serif text-2xl text-clay sm:text-3xl">{p.title}</h3>
                <p className="mt-3 max-w-md text-sm leading-relaxed text-stone-300 sm:text-base">
                  {p.body}
                </p>
              </div>
            </article>
          ))}

          <article
            data-testid="program-card-relief"
            className="group relative overflow-hidden rounded-3xl bg-maroon p-7 sm:p-10 lg:col-span-12"
          >
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div className="max-w-2xl">
                <span className="font-serif text-sm text-saffron-bright">
                  06 · <span className="hindi">राहत</span>
                </span>
                <h3 className="mt-2 font-serif text-2xl text-clay sm:text-3xl">
                  Disaster &amp; Pandemic Relief
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-stone-300 sm:text-base">
                  When many stayed home during the COVID-19 pandemic, our volunteers were out on
                  the streets — distributing food and essential supplies to those who needed them
                  most. We stay ready for the next emergency.
                </p>
              </div>
              <button
                data-testid="program-relief-volunteer-cta"
                onClick={() => scrollToSection("volunteer")}
                className="rounded-full bg-saffron px-6 py-3 text-sm font-semibold text-ink transition-colors hover:bg-saffron-bright"
              >
                Join the next drive
              </button>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}
