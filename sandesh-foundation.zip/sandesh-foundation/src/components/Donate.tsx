import { useState } from "react";
import { Copy, Check, Landmark, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { BANK_ROWS, ORG, UPI } from "../lib/content";
import { Reveal, SectionHeading } from "./Shared";

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Fallback for non-secure contexts / older browsers
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  }
}

function CopyButton({
  label,
  value,
  testId,
  className,
}: {
  label: string;
  value: string;
  testId: string;
  className: string;
}) {
  const [done, setDone] = useState(false);
  const onClick = async () => {
    const ok = await copyText(value);
    if (!ok) {
      toast.error("Could not copy. Please copy it manually.");
      return;
    }
    toast.success(`${label} copied`);
    setDone(true);
    window.setTimeout(() => setDone(false), 1600);
  };
  return (
    <button
      data-testid={`${testId}-copy-button`}
      aria-label={`Copy ${label}`}
      onClick={onClick}
      className={className}
    >
      {done ? <Check className="h-4 w-4" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
    </button>
  );
}

export default function Donate() {
  return (
    <section id="donate" data-testid="donation-details-section" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeading
              hindi="दान"
              english="Donate"
              title="Every gift carries a message of hope."
              description="You can donate directly to our bank account or over UPI (Google Pay, PhonePe, Amazon Pay). Every rupee goes to the ground — teaching children, running health camps, planting trees."
            />
            <Reveal>
              <div className="mt-8 rounded-2xl border border-saffron/40 bg-saffron/10 p-6">
                <p className="font-serif text-lg text-terracotta">Help one person. Change one world.</p>
                <p className="mt-2 text-sm leading-relaxed text-stone-600">
                  For any questions about donating, call us on{" "}
                  <a
                    href={ORG.phoneHref}
                    data-testid="donate-phone-link"
                    className="font-semibold text-maroon underline decoration-saffron decoration-2 underline-offset-4"
                  >
                    {ORG.phoneDisplay}
                  </a>
                  .
                </p>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <Reveal>
              <div className="overflow-hidden rounded-3xl border border-maroon/10 bg-white shadow-[0_30px_60px_-30px_rgba(88,24,29,0.25)]">
                <div className="flex items-center gap-3 bg-maroon px-7 py-5 text-clay sm:px-9">
                  <Landmark className="h-5 w-5 text-saffron-bright" aria-hidden="true" />
                  <p className="font-serif text-lg">Bank transfer details</p>
                </div>
                <div className="px-7 py-3 sm:px-9">
                  {BANK_ROWS.map((r) => (
                    <div
                      key={r.testId}
                      className="flex items-center justify-between gap-4 border-b border-maroon/10 py-4 last:border-0"
                    >
                      <div>
                        <p className="text-xs uppercase tracking-[0.2em] text-stone-500">{r.label}</p>
                        <p data-testid={r.testId} className="mt-1 font-serif text-lg text-maroon sm:text-xl">
                          {r.value}
                        </p>
                      </div>
                      <CopyButton
                        label={r.label}
                        value={r.value}
                        testId={r.testId}
                        className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-maroon/20 text-maroon transition-all hover:bg-maroon hover:text-clay"
                      />
                    </div>
                  ))}
                </div>
                <div className="border-t border-maroon/10 bg-sand px-7 py-6 sm:px-9">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <Smartphone className="h-5 w-5 text-saffron" aria-hidden="true" />
                      <div>
                        <p className="text-xs uppercase tracking-[0.2em] text-stone-500">
                          UPI — Google Pay · PhonePe · Amazon Pay
                        </p>
                        <p data-testid={UPI.testId} className="mt-1 font-serif text-lg text-maroon sm:text-xl">
                          {UPI.value}
                        </p>
                      </div>
                    </div>
                    <CopyButton
                      label={UPI.label}
                      value={UPI.value}
                      testId={UPI.testId}
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-saffron text-ink transition-colors hover:bg-saffron-bright"
                    />
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
