import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { HeartHandshake, Menu, Phone, X } from "lucide-react";
import { NAV_LINKS, ORG, type SectionId } from "../lib/content";
import { scrollToSection } from "../lib/scroll";
import { Logo } from "./Shared";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Solid header whenever the page is scrolled or the mobile menu is open.
  const solid = scrolled || open;

  const go = (id: SectionId) => {
    setOpen(false);
    scrollToSection(id);
  };

  return (
    <header
      data-testid="main-navigation"
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 border-b ${
        solid
          ? "border-maroon/10 bg-clay/90 backdrop-blur-md"
          : "border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8 md:h-20">
        <Logo tone={solid ? "onLight" : "onDark"} />

        <nav className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((l) => (
            <button
              key={l.id}
              data-testid={`nav-link-${l.id}`}
              onClick={() => go(l.id)}
              className={`group relative text-sm font-medium tracking-wide transition-colors ${
                solid
                  ? "text-ink/80 hover:text-maroon"
                  : "text-clay/90 hover:text-saffron-bright"
              }`}
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 transition-transform duration-300 group-hover:scale-x-100 bg-saffron"></span>
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2.5">
          <a
            href={ORG.phoneHref}
            data-testid="nav-phone-link"
            className={`hidden items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-all md:inline-flex ${
              solid
                ? "border-maroon/20 text-maroon hover:bg-maroon/5"
                : "border-clay/30 text-clay hover:bg-clay/10"
            }`}
          >
            <Phone className="h-4 w-4" aria-hidden="true" /> {ORG.phoneDisplay}
          </a>
          <button
            data-testid="nav-donate-button"
            onClick={() => go("donate")}
            className={`hidden items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all md:inline-flex ${
              solid
                ? "bg-maroon text-clay hover:bg-maroon-deep"
                : "bg-saffron text-ink hover:bg-saffron-bright"
            }`}
          >
            <HeartHandshake className="h-4 w-4" aria-hidden="true" /> Donate
          </button>
          <button
            data-testid="nav-mobile-toggle"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className={`inline-flex h-10 w-10 items-center justify-center rounded-full border transition-colors lg:hidden ${
              solid ? "border-maroon/20 text-maroon" : "border-clay/30 text-clay"
            }`}
          >
            {open ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            data-testid="nav-mobile-menu"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden border-t border-maroon/10 bg-clay lg:hidden"
          >
            <div className="mx-auto flex max-w-7xl flex-col px-5 py-4 sm:px-8">
              {NAV_LINKS.map((l) => (
                <button
                  key={l.id}
                  data-testid={`nav-mobile-link-${l.id}`}
                  onClick={() => go(l.id)}
                  className="border-b border-maroon/10 py-4 text-left font-serif text-xl text-maroon"
                >
                  {l.label}
                </button>
              ))}
              <div className="mt-5 flex flex-wrap items-center gap-3 pb-2">
                <a
                  href={ORG.phoneHref}
                  className="inline-flex items-center gap-2 rounded-full border border-maroon/20 px-4 py-2 text-sm font-medium text-maroon"
                >
                  <Phone className="h-4 w-4" aria-hidden="true" /> {ORG.phoneDisplay}
                </a>
                <button
                  onClick={() => go("donate")}
                  className="inline-flex items-center gap-2 rounded-full bg-maroon px-5 py-2.5 text-sm font-semibold text-clay"
                >
                  <HeartHandshake className="h-4 w-4" aria-hidden="true" /> Donate
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
