import { Fragment } from "react";
import { MARQUEE_ITEMS } from "../lib/content";

function Track({ hidden = false }: { hidden?: boolean }) {
  return (
    <div className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {MARQUEE_ITEMS.map((m) => (
        <Fragment key={m.english}>
          <span className="flex items-center">
            <span className="whitespace-nowrap px-8 font-serif text-2xl tracking-tight sm:text-3xl hindi text-maroon">
              {m.hindi}
            </span>
            <span className="inline-block h-2 w-2 rounded-full bg-saffron"></span>
          </span>
          <span className="flex items-center">
            <span className="whitespace-nowrap px-8 font-serif text-2xl tracking-tight sm:text-3xl italic text-terracotta">
              {m.english}
            </span>
            <span className="inline-block h-2 w-2 rounded-full bg-saffron"></span>
          </span>
        </Fragment>
      ))}
    </div>
  );
}

export default function Marquee() {
  return (
    <section
      data-testid="editorial-marquee"
      className="marquee overflow-hidden border-y border-maroon/10 bg-sand py-7"
      aria-label="Our focus areas"
    >
      <div className="marquee-track flex w-max">
        <Track />
        <Track hidden />
      </div>
    </section>
  );
}
