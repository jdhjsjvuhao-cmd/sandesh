import { Check, Quote } from "lucide-react";
import { ABOUT_POINTS } from "../lib/content";
import { IMG } from "../lib/images";
import { Reveal, SectionHeading } from "./Shared";

export default function About() {
  return (
    <section id="about" data-testid="about-section" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                hindi="हमारे बारे में"
                english="About"
                title="Started with an extraordinary dream — a society that is educated and healthy."
              />
              <Reveal>
                <div className="mt-10 overflow-hidden rounded-2xl border border-maroon/10 bg-white/70">
                  <img
                    src={IMG.founder}
                    alt="Sandeep Pandey — Founder & Chairman"
                    className="h-60 w-full object-cover object-top"
                  />
                  <div className="p-7">
                    <p className="font-serif text-lg font-semibold text-maroon">Sandeep Pandey</p>
                    <p className="text-xs uppercase tracking-[0.2em] text-saffron">Founder &amp; Chairman</p>
                    <p className="mt-3 text-sm leading-relaxed text-stone-600">
                      After retiring from the Indian Navy, Sandeep began with a small group to make
                      people aware of society's burning problems. Today, the Sandesh Foundation
                      family has taken a big form — beyond gender, class, religion, politics and
                      caste.
                    </p>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>

          <div className="lg:col-span-7 lg:pl-8">
            <Reveal>
              <p className="font-serif text-xl leading-relaxed text-ink sm:text-2xl">
                Sandesh Foundation is a non-religious, non-profit, public service organization
                that carries a simple <em className="text-terracotta">sandesh</em> — a message — of
                health, education and environment. We work where natural resources and human
                dignity have turned from assets into liabilities, and we work to change that.
              </p>
            </Reveal>
            <Reveal delay={0.08}>
              <p className="mt-7 text-base leading-relaxed text-stone-600 sm:text-lg">
                Our objective is to reduce poverty and social evils, fight lack of education and
                child labour, improve public health, support the needy, enable rural development,
                protect the environment and run livelihood programmes — raising these issues and
                correcting them, on the ground, every day.
              </p>
            </Reveal>

            <div className="mt-10 grid gap-x-8 gap-y-4 sm:grid-cols-2">
              {ABOUT_POINTS.map((p, i) => (
                <Reveal key={p} delay={(i % 2) * 0.06}>
                  <div className="flex items-center gap-3 border-b border-maroon/10 py-3">
                    <Check className="h-4 w-4 shrink-0 text-saffron" aria-hidden="true" />
                    <span className="text-sm font-medium text-ink sm:text-base">{p}</span>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal>
              <figure
                data-testid="about-quote"
                className="relative mt-14 rounded-3xl bg-maroon p-9 text-clay sm:p-12"
              >
                <Quote className="h-8 w-8 text-saffron-bright" aria-hidden="true" />
                <blockquote className="mt-5 font-serif text-2xl italic leading-snug sm:text-3xl">
                  Helping one person might not change the whole world, but it could change the
                  world for one person.
                </blockquote>
                <figcaption className="mt-6 text-xs uppercase tracking-[0.25em] text-stone-400">
                  — The Sandesh belief
                </figcaption>
              </figure>
            </Reveal>

            <Reveal>
              <div data-testid="about-testimonial" className="mt-8 border-l-2 border-saffron pl-6">
                <p className="text-base italic leading-relaxed text-stone-600 sm:text-lg">
                  "When many people stayed in their homes, Sandesh Foundation was distributing food
                  and other necessary things to help others in this COVID-19 pandemic. I am very
                  impressed with the team's intention and way of doing social work — after
                  completing my studies, I will definitely join."
                </p>
                <p className="mt-3 text-xs uppercase tracking-[0.2em] text-stone-500">
                  — A college student &amp; future volunteer
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
