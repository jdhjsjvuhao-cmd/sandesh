import { useEffect } from "react";
import { Toaster } from "sonner";
import { initSmoothScroll } from "./lib/scroll";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import About from "./components/About";
import Programs from "./components/Programs";
import Gallery from "./components/Gallery";
import Volunteer from "./components/Volunteer";
import Donate from "./components/Donate";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  useEffect(() => initSmoothScroll(), []);

  return (
    <div className="relative min-h-screen bg-clay font-sans text-ink">
      <div className="grain" aria-hidden="true"></div>
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Programs />
        <Gallery />
        <Volunteer />
        <Donate />
        <Contact />
      </main>
      <Footer />
      <Toaster position="top-center" richColors closeButton />
    </div>
  );
}
