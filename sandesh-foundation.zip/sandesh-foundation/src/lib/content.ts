import { IMG } from "./images";

export const ORG = {
  name: "Sandesh Foundation",
  tagline: "संदेश — आशा की किरण",
  phoneDisplay: "09495 511 524",
  phoneRaw: "09495511524",
  phoneHref: "tel:09495511524",
  address:
    "32, Daktar Colony, Poni Road, Gangaghat, Shuklaganj, Unnao, Uttar Pradesh 209861",
  facebookUrl: "https://www.facebook.com/SandeshFoundation07/",
  facebookHandle: "SandeshFoundation07",
};

export type SectionId =
  | "top"
  | "about"
  | "programs"
  | "gallery"
  | "volunteer"
  | "donate"
  | "contact";

export const NAV_LINKS: { id: SectionId; label: string }[] = [
  { id: "about", label: "About" },
  { id: "programs", label: "Programs" },
  { id: "gallery", label: "Gallery" },
  { id: "volunteer", label: "Volunteer" },
  { id: "contact", label: "Contact" },
];

export const FOOTER_LINKS: { id: SectionId; label: string }[] = [
  { id: "about", label: "About" },
  { id: "programs", label: "Programs" },
  { id: "gallery", label: "Gallery" },
  { id: "volunteer", label: "Volunteer" },
  { id: "donate", label: "Donate" },
  { id: "contact", label: "Contact" },
];

export const MARQUEE_ITEMS: { hindi: string; english: string }[] = [
  { hindi: "शिक्षा", english: "Education" },
  { hindi: "स्वास्थ्य", english: "Health" },
  { hindi: "पर्यावरण", english: "Environment" },
  { hindi: "महिला सशक्तिकरण", english: "Empowerment" },
  { hindi: "वस्त्र दान", english: "Cloth Donation" },
  { hindi: "राहत", english: "Relief" },
];

export const ABOUT_POINTS = [
  "Poverty reduction",
  "Education for every child",
  "Public health",
  "An end to child labour",
  "Women's education",
  "Rural development",
  "Environmental protection",
  "Livelihood programmes",
];

export interface Program {
  n: string;
  hindi: string;
  title: string;
  body: string;
  image: string;
  alt: string;
  span: string;
}

export const PROGRAMS: Program[] = [
  {
    n: "01",
    hindi: "शिक्षा",
    title: "Education for Child",
    body: "Each child deserves an education, yet millions cannot attend school because of poverty. We support children with quality education, books and extra-curricular activities — raising their standard of living and leading them to a brighter future.",
    image: IMG.education,
    alt: "Children studying at a learning centre",
    span: "lg:col-span-8",
  },
  {
    n: "02",
    hindi: "स्वास्थ्य",
    title: "Health Care Program",
    body: "Health camps, immunization and polio vaccination drives, and general check-ups for communities that rarely see a doctor.",
    image: IMG.healthcare,
    alt: "A community health camp in progress",
    span: "lg:col-span-4",
  },
  {
    n: "03",
    hindi: "पर्यावरण",
    title: "Clean Environment",
    body: "Tree plantation drives, waste management and recycling — restoring the land, water and forests that sustain us.",
    image: IMG.environment,
    alt: "Volunteers planting saplings",
    span: "lg:col-span-4",
  },
  {
    n: "04",
    hindi: "महिला सशक्तिकरण",
    title: "Women Empowerment",
    body: "Awareness programmes on gender equality, education for women, and support toward skills and self-reliance.",
    image: IMG.women,
    alt: "Women at a community workshop",
    span: "lg:col-span-4",
  },
  {
    n: "05",
    hindi: "वस्त्र दान",
    title: "Cloth Donation",
    body: "Clothing donation drives that bring dignity to the needy while giving old clothes a second life through recycling.",
    image: IMG.clothDonation,
    alt: "Cloth donation drive volunteers",
    span: "lg:col-span-4",
  },
];

export type GalleryCategory = "education" | "health" | "environment" | "community";

export const GALLERY_FILTERS: { key: "all" | GalleryCategory; label: string }[] = [
  { key: "all", label: "All" },
  { key: "education", label: "Education" },
  { key: "health", label: "Health" },
  { key: "environment", label: "Environment" },
  { key: "community", label: "Community" },
];

const CATEGORY_HINDI: Record<GalleryCategory, string> = {
  education: "शिक्षा",
  health: "स्वास्थ्य",
  environment: "पर्यावरण",
  community: "समाज",
};

export interface GalleryItem {
  src: string;
  caption: string;
  category: GalleryCategory;
  tall?: boolean;
}

export const GALLERY: GalleryItem[] = [
  { src: IMG.education, caption: "Class in session — learning centre", category: "education", tall: true },
  { src: IMG.healthcare, caption: "Health camp — registration & support", category: "health" },
  { src: IMG.school, caption: "School is where the future begins", category: "education" },
  { src: IMG.about, caption: "Seva with a smile", category: "community" },
  { src: IMG.main2, caption: "The family gathers — community event", category: "community", tall: true },
  { src: IMG.environment, caption: "Shramdaan — community cleanliness drive", category: "environment" },
  { src: IMG.doctor, caption: "Doctor's check-up at the camp", category: "health" },
  { src: IMG.foundationDay, caption: "Foundation Day — food & fruits for the elders", category: "community" },
  { src: IMG.saplings, caption: "Saplings for the plantation drive", category: "environment" },
  { src: IMG.joy, caption: "Joy, after class", category: "community" },
];

export const categoryHindi = (c: GalleryCategory) => CATEGORY_HINDI[c];

export const VOLUNTEER_POINTS = [
  "Teach at learning centres or join weekend health camps",
  "Plant trees, run cloth-donation and cleanliness drives",
  "Help with relief work when the next emergency comes",
];

export const INTERESTS = [
  "Teaching & Education",
  "Health Camps",
  "Environment & Plantation",
  "Cloth Donation Drives",
  "Relief Work",
  "Fundraising & Social Media",
];

export const AVAILABILITY = ["Weekends", "Weekdays", "Remote / online", "Anytime"];

export const BANK_ROWS: { label: string; value: string; testId: string }[] = [
  { label: "Account name", value: "Sandesh Foundation", testId: "donate-account-name" },
  { label: "Bank & branch", value: "HDFC Bank · Netua Shuklaganj (Unnao)", testId: "donate-bank-branch" },
  { label: "Account number", value: "50100251425771", testId: "donate-account-number" },
  { label: "IFSC code", value: "HDFC0004429", testId: "donate-ifsc-code" },
];

export const UPI = { label: "UPI number", value: "09495511524", testId: "donate-upi-number" };

export const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/&/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
