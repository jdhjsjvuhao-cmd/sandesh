/**
 * Image sources.
 *
 * - Files under /images are the reference site's own uploads. Copy them from the
 *   saved-page folder into `public/images/` (see public/images/README.md).
 * - The Unsplash entries are the stock photos the reference site loads; they are
 *   hot-linked here. To self-host them, download each file into `public/images/`
 *   and point the value at `/images/<name>.jpg`.
 */
const unsplash = (id: string, w = 1600) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

export const IMG = {
  logo: "/images/logo.jpg",
  founder: "/images/founder.jpg",
  education: "/images/education.jpg",
  healthcare: "/images/healthcare.jpg",
  environment: "/images/environment.jpg",
  about: "/images/about.jpg",
  main2: "/images/main2.jpg",
  foundationDay: "/images/foundation-day.jpg",

  hero: unsplash("photo-1623303366639-0e330d7c3d9f", 2200),
  women: unsplash("photo-1463335361701-e90f4c5045d0"),
  clothDonation: unsplash("photo-1577604981316-298e453a19dd"),
  school: unsplash("photo-1524069290683-0457abfe42c3"),
  doctor: unsplash("photo-1680759290820-db921524617c"),
  saplings: unsplash("photo-1708592955370-31f2e651f539"),
  joy: unsplash("photo-1489942986787-cded4ecf962e"),
} as const;
