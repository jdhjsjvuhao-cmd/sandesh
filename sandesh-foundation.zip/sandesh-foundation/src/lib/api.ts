export interface ApiResult {
  ok: boolean;
  message?: string;
}

export async function postJSON(url: string, body: unknown): Promise<ApiResult> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) return { ok: false, message: data.error ?? "Something went wrong." };
    return { ok: true };
  } catch {
    return { ok: false, message: "Network error. Please try again." };
  }
}
