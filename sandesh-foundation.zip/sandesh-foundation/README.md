# Sandesh Foundation — website

React + TypeScript + Vite + Tailwind CSS 3, deployable on Cloudflare Pages.
Rebuilt from the saved copy of `https://sandesh-rebuild.preview.emergentagent.com/`.

It is a single-page site (`/`) with these sections: Hero, Marquee, About, Programs,
Gallery (with filters), Volunteer form, Donate (bank/UPI copy buttons), Contact form, Footer.
Navigation scrolls to sections; there are no other routes.

## 1. Add the images

Copy the 8 site images from your saved-page folder into `public/images/`
(names and list in `public/images/README.md`). The 7 stock photos load from Unsplash.

## 2. Run locally

```bash
npm install
npm run dev          # http://localhost:3000
```

The forms need the backend (step 3). To test them locally with Cloudflare Functions + D1:

```bash
npx wrangler d1 create sandesh-db          # paste the database_id into wrangler.toml
npm run db:init:local
npm run pages:dev                          # builds, then serves dist + /api/* locally
```

## 3. Deploy to Cloudflare Pages

```bash
npx wrangler login
npx wrangler d1 create sandesh-db          # once; copy database_id into wrangler.toml
npm run db:init:remote                     # creates the volunteers / inquiries tables
npm run pages:deploy
```

Then in the Cloudflare dashboard: **Workers & Pages → sandesh-foundation → Settings →
Functions → D1 database bindings** → add binding `DB` → `sandesh-db` (Production and Preview).

Or connect the Git repo to Pages with build command `npm run build` and output directory `dist`
(the `functions/` folder is picked up automatically).

Read submissions:

```bash
npx wrangler d1 execute sandesh-db --remote --command "SELECT * FROM volunteers ORDER BY id DESC LIMIT 50"
npx wrangler d1 execute sandesh-db --remote --command "SELECT * FROM inquiries ORDER BY id DESC LIMIT 50"
```

## Structure

```
src/components/   one file per section (Nav, Hero, Marquee, About, Programs, Gallery, Volunteer, Donate, Contact, Footer)
src/lib/content.ts   all copy, bank details, gallery and program data
src/lib/images.ts    image sources
functions/api/       Cloudflare Pages Functions: POST /api/volunteer, POST /api/contact (D1)
reference/           original compiled CSS + cleaned DOM of the reference page, for diffing
```

## Things taken from the reference vs. estimated

Taken directly from the saved page: all text, section structure, class names, colors
(`tailwind.config.js`), fonts (DM Sans, Fraunces, Rozha One, Noto Serif Devanagari),
icons (lucide), image mapping, gallery categories and bank/UPI details.

Not visible in a saved page, so estimated — compare against the live site and adjust:
animation timings and easing (framer-motion), hero parallax amount, the mobile menu panel,
toast wording and position, the nav's transparent state at the top of the page, and what the
original backend did with form submissions.
